<?php
echo "<h1>Lecture des donn�es </h1>";
foreach($_POST as $cle=>$valeur)
{
  echo "$cle : $valeur <br />";
}
echo "<h1>Informations sur le fichier transf�r�</h1>";
foreach($_FILES as $tab)
{
 foreach($tab as $cle=>$valeur)
 {
   echo "$cle : $valeur <br />";
 }
}
?>