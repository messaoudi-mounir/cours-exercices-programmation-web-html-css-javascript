<?php
echo "<h1>Lecture des donn�es </h1>";
foreach($_POST as $cle=>$valeur)
{
  echo "$cle : $valeur <br />";
}
?>